WONDERDOT - RPG Dungeon Tileset + Hero & Slime

License : https://www.gamedevmarket.net/terms-conditions/#pro-licence

===========================================================

v1.1 ------------------------------------------------------

-Cave walls
-Dirt floor extra tiles
-Lever (3 states)

v1.0 ------------------------------------------------------

-Dungeon floor
	Basic dungeon floor
	Dirt floor   (13 autotile patch + 4 variation tiles)
	Raised floor (13 autotile patch)
	Pit (13 autotile patch)
	Coloured tiles (3 palette swaps)
-Dungeon walls (16 autotile wall set)
	Alternate damaged wall tiles
-Steps & second level wall
-Stairs (up/down)
-Wood door, Iron bar gate, door archway
-Animated spikes
-Animated torches (wall & pillar versions)
-Props
	Pillar (+broken pillar)
	Rubble (2x2, 2x1, 1x1 versions)
	Shelves (4 versions)
	Weapon rack (3 versions)
	Chest (open/closed)
	Pot (+ broken version)
	Alternate pots
	Table
	Stone throne
	Stool
	Crate (+broken version)
	Wood pile
	Prison chains

===========================================================

Thank you for your support!

-Pita

silverdeluxe.tumblr.com
twitter.com/pita_akm